package com.net.entities;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;



public class HibernateOperation {
	
	@Test
	public void tetsSaveMethodInHibernate(){
		
		Employee employee = new Employee();
		save(employee);
	}
	
	public static Employee save(Employee employee) {
		
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		Long id = (Long) session.save(employee);
		employee.setId(id);
		session.getTransaction().commit();
		session.close();
		return employee;
	}

}
