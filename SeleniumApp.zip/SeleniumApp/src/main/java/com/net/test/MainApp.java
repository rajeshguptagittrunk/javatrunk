package com.net.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MainApp {
	
	
	
	@Before
    public void runBeforeTestMethod() {
        System.out.println("@Before - runBeforeTestMethod");
    }

    // Should rename to @AfterTestMethod
    @After
    public void runAfterTestMethod() {
        System.out.println("@After - runAfterTestMethod");
    }
	
	@Test
	public static void main() {
		ScrapingService scrapingService = new ScrapingServiceImpl();
		scrapingService.scrapCCBillTransactions();
	}
}
