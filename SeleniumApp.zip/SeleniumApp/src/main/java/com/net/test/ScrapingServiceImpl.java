package com.net.test;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.bcel.generic.GOTO;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;

//import com.electronicgroups.adm.domain.CCBillTransaction;
//import com.electronicgroups.adm.domain.CCBillTransactionActive;
//import com.electronicgroups.adm.domain.CCBillTransactionType;
////import com.electronicgroups.adm.domain.OrderTransactionActive;
////import com.electronicgroups.adm.domain.OrderTransactionType;
//import com.electronicgroups.adm.domain.ScrapingLog;
//import com.electronicgroups.adm.domain.ScrapingStatus;
import com.google.common.base.Function;
import com.net.entities.Employee;
import com.net.entities.HibernateOperation;


public class ScrapingServiceImpl implements ScrapingService {

    protected final Logger logger = Logger.getLogger(getClass());

    @Autowired
    private transient MailSender mailTemplate;
    
    //@Autowired
    //private transient MongoDBDao mongoDBDao;
    
    String mailFrom;
    String mailTo;
    String ccbAffiliate="593693";
    String ccbUsername="ecocozza";
    String ccbPassword="kGA5wZPqolYy";
    String startDate;
    
    
    @Override
    public void scrapCCBillTransactions() {
//        List<CCBillTransaction> newTransactions = new ArrayList<CCBillTransaction>();
//        ScrapingLog log = new ScrapingLog();
//        log.setNewTransactionsFound(newTransactions.size());
//        log.setDateRun(new Date());

        // CCBill server is located in Arizona
    	
    	Properties properties = new Properties();
    	Employee employee = new Employee();
    	
    	logger.info("CCBill server is located in Arizona-----------------[wait for 120..seconds]-------------------->>");
    	WebDriver driver = null;
	    try {
	    	
	        properties.load(getClass().getClassLoader().getResourceAsStream("credensials.properties"));
	    	
	        DateFormat longDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        longDateFormat.setTimeZone(TimeZone.getTimeZone("US/Arizona"));
	        DateFormat shortDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	        shortDateFormat.setTimeZone(TimeZone.getTimeZone("US/Arizona"));
	        DateFormat rebillDateFormat = new SimpleDateFormat("dd MMM yyyy");
	        rebillDateFormat.setTimeZone(TimeZone.getTimeZone("US/Arizona"));
	        NumberFormat orderAmountFormat = new DecimalFormat("$#,##0.00");
	        
	            driver = new FirefoxDriver();
	            // used to force the driver to try to find elements during two minutes
	            // so we can make sure the page is fully loaded on each transition.
	            WebDriverWait wait = new WebDriverWait(driver, 120);
	            // load the main page.
	            driver.get(properties.getProperty("link.url"));
	            // enter login data and submit
	            wait.until(findElement(By.id("loginform")));
	            driver.findElement(By.id("loginform")).click();
	            driver.findElement(By.id("txtEmail")).click();
	            driver.findElement(By.id("txtEmail")).clear();
	            driver.findElement(By.id("txtEmail")).sendKeys(properties.getProperty("link.user"));
	            driver.findElement(By.id("txtPassword")).clear();
	            driver.findElement(By.id("txtPassword")).sendKeys(properties.getProperty("link.password"));
	            driver.findElement(By.id("btnLogin")).click();
	            
	            wait.until(findElement(By.linkText("My Attendance")));
	            driver.findElement(By.linkText("My Attendance")).click();
	            
	            // wait for the transactions frame to fully load and then switch focus to it
	            wait.until(findElement(By.id("ContentPlaceHolder1_updatePanelIndividualAttendance")));
	            
	            // unique element that tell us the main report is actually displayed.
	            String xpathToMainTR = "//table[@class='table table-striped']//tbody//tr";
	            // unique element that tell us a subreport is actually displayed.
	            String xpathToMainTRTD = "//table[@class='table table-striped']//tr//td";
	            // this expression gets all the links from the subreports
	            String xpathToAllSubReportTotalTime = "//table[@class='table table-striped']//tr[@class='totalTime']//td";
	            String xpathToAllSubReportLinks = "//table[@class='reportTable']//tr//td//span[@id='ContentPlaceHolder1_lvDataPager']//a[position()=5]/@href";
	            // this gets the back button
	//            String xptahToBackButton = "//img[@src='/images/htmlengine/back_off.gif'] | //img[@src='/images/htmlengine/back_on.gif']";
	            
	            logger.info("xpathToAllSubReportLinks : -------------------------->>"+xpathToAllSubReportLinks);
	            
	            int currentReportIndex = 0;
	            int totaltableRow = 0;
	            int totaltableRowData = 0;
	            int totaltableRowDataTotalTime = 0;
	            int totaltableRowDataLinks = 0;
	            int timesToHitBackButton = 0;
	            int currentReportColumnIndex = 0;
	            int rowcount = 0;
	            
	            totaltableRow = wait.until(findElements(By.xpath(xpathToMainTR))).size();
	            totaltableRowData = wait.until(findElements(By.xpath(xpathToMainTRTD))).size();
	            totaltableRowDataTotalTime = wait.until(findElements(By.xpath(xpathToAllSubReportTotalTime))).size();
	            totaltableRowDataLinks = wait.until(findElements(By.xpath(xpathToAllSubReportLinks))).size();
	            
	            logger.info("totaltableRow : -------------------------->>"+totaltableRow);
	            logger.info("totaltableRowData : -------------------------->>"+totaltableRowData);
	            logger.info("totaltableRowDataTotalTime : -------------------------->>"+totaltableRowDataTotalTime);
	            logger.info("totaltableRowDataLinks : -------------------------->>"+totaltableRowDataLinks);
	            
	            callBack :
	            while ( totaltableRow > currentReportIndex ) {
	            
		            wait.until(findElement(By.xpath(xpathToMainTR)));
		            
		            Map<Integer,String> indexToColumnNameMap = new HashMap<Integer,String>(totaltableRowData);
		            for (WebElement cell : wait.until(findElements(By.xpath(xpathToMainTRTD)))) {
		                // format lower case and change spaces to underline scores
		                indexToColumnNameMap.put(currentReportColumnIndex++, (cell.getText().toLowerCase()).replace(" ", "_"));
		            }
		            
		            
		            for (WebElement row : wait.until(findElements(By.xpath(xpathToMainTR)))) {
		            	
		            	currentReportColumnIndex = 1;
		            	int rowdata = 0;
		            	logger.info("currentReportColumnIndex=================================================================>>"+(++rowcount));
		            	totaltableRow--;
		            	for (WebElement cell :row.findElements(By.tagName("td"))) {
		            		
		            		 if (!cell.getText().trim().isEmpty()) {
		            		 	 
		            		 	 if( ! (cell.getText().trim().contains("Next")) & ! (cell.getText().trim().contains("Expected Hours")) & !(cell.getText().trim().contains("Attendance"))){
		            		 		rowdata++;
		            		 	 	 logger.info("=================================================================>>"+(cell.getText().trim()));
		            		 	 	switch (rowdata) {
		            		 	 		case 1:
		            		 	 			employee.setSno(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 2:
		            		 	 			employee.setDate(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 3:
		            		 	 			employee.setAttendance(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 4:
		            		 	 			employee.setInTime(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 5:
		            		 	 			employee.setOutTime(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 6:
		            		 	 			employee.setTotalTime(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 7:
		            		 	 			employee.setVerified(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 8:
		            		 	 			employee.setVerifiedBy(cell.getText().trim());
		            		 	 			break;
		            		 	 		case 9:
		            		 	 			employee.setRemarks(cell.getText().trim());
		            		 	 			break;
		            		 	 		default:
		            		 	 		System.out.println("DEFAULT BLOCK :-------------------------->>"+cell.getText().trim());
		            		 	 		break;
		            		 	 	}
		            		 	 }
		            			 else{
		            				 
		            			 }
		            		 }
		            		currentReportColumnIndex++;
		            		
		            		if(cell.getText().trim().contains("Next")){
	            				 currentReportIndex++;
		            			 totaltableRow = 0;
			                     WebElement next = driver.findElement(By.partialLinkText("Next"));
			                     next.click();
			                     waitUntilElementIsRefreshed(driver, next, By.partialLinkText("Next"));
			                     timesToHitBackButton--;
			                     
			                     //re-init table values
			                     totaltableRow = wait.until(findElements(By.xpath(xpathToMainTR))).size();
			                     totaltableRowData = wait.until(findElements(By.xpath(xpathToMainTRTD))).size();
			                     totaltableRowDataTotalTime = wait.until(findElements(By.xpath(xpathToAllSubReportTotalTime))).size();
			                     totaltableRowDataLinks = wait.until(findElements(By.xpath(xpathToAllSubReportLinks))).size();
			                     continue callBack;
		            		}
		            	}
		            	
		            	HibernateOperation.save(employee);
		            }
	            }
	     } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
//            log.setStatus(ScrapingStatus.ERROR);
//            log.setMessage(e.getMessage());
//            sendStatusMessage(newTransactions, null, e);
//            throw new RuntimeException(e.getMessage(), e);
        } finally {
            if (driver != null) {
                driver.close();
            }
//            log.persist();
        }
    }

    private void waitUntilElementIsRefreshed(WebDriver driver, WebElement element, By locator) {
        final int MAXIMUM_WAIT_SECONDS = 20;
        WebDriverWait wait = new WebDriverWait(driver, MAXIMUM_WAIT_SECONDS);
        long initialTime = System.currentTimeMillis();
        while (element.equals(wait.until(findElement(locator)))) {
            if (elapsedTimeSeconds(initialTime) < MAXIMUM_WAIT_SECONDS) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                    logger.warn("Interrupt received! Returning...");
                    return;
                }
            } else {
                throw new TimeoutException("The element with locator: " + locator + " failed to refresh after " + elapsedTimeSeconds(initialTime) + " seconds...");
            }
        }
        logger.debug("Time elapsed until element with locator - " + locator + " - refresh: " + elapsedTimeSeconds(initialTime) + " seconds");
    }

    private long elapsedTimeSeconds(long initialTime) {
        return (System.currentTimeMillis() - initialTime) / 1000;
    }

    private Function<WebDriver, WebElement> findElement(final By locator) {
        return new Function<WebDriver, WebElement>() {

            public WebElement apply(WebDriver driver) {
                return driver.findElement(locator);
            }
        };
    }

    private Function<WebDriver, List<WebElement>> findElements(final By locator) {
        return new Function<WebDriver, List<WebElement>>() {

            public List<WebElement> apply(WebDriver driver) {
                return driver.findElements(locator);
            }
        };
    }
    
    private void sendStatusMessage(List<?> newObjects, List<?> earlierObjects, Throwable t) {
        org.springframework.mail.SimpleMailMessage simpleMailMessage = new org.springframework.mail.SimpleMailMessage();
        simpleMailMessage.setFrom(mailFrom);
        simpleMailMessage.setTo(mailTo.split(","));
        if (t == null) {
            simpleMailMessage.setSubject("Scraping Successfull");
        } else {
            simpleMailMessage.setSubject("Scraping Finished with Errors");
        }

        StringBuilder detailedMessage = new StringBuilder();
        if (newObjects.size() > 0) {
            detailedMessage.append("\r\n\r\n").append("=====New Sales=====");
            for (Object object : newObjects) {
                detailedMessage.append("\r\n\r\n").append(verticalizeToString(object));
            }
            if (earlierObjects != null && earlierObjects.size() > 0) {
                detailedMessage.append("\r\n\r\n").append("=====Earlier Sales=====");
                for (Object object : earlierObjects) {
                    detailedMessage.append("\r\n\r\n").append(verticalizeToString(object));
                }
            }
        }

        if (t != null) {
            detailedMessage.append("\r\n\r\n").append("=====Exception=====");
            detailedMessage.append("\r\n").append(t.getMessage());
            detailedMessage.append("\r\n").append(getStackTrace(t));
        }

        simpleMailMessage.setText(detailedMessage.toString());
        mailTemplate.send(simpleMailMessage);
    }
    
    private static String verticalizeToString(Object object) {
        return (object != null)?object.toString().replace(", ", "\r\n"):null;
    }
    
    private static String getStackTrace(Throwable t)
    {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw, true);
        t.printStackTrace(pw);
        pw.flush();
        sw.flush();
        return sw.toString();
    }
}
