package com.net.test;

public interface ScrapingService {
	public void scrapCCBillTransactions();
}
